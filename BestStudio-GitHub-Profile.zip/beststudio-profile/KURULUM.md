# Best Studio — GitHub Profil Kurulumu

Bu paket `ybeststudio` hesabı için hazırlanmıştır. Profil metni İngilizce, kurulum açıklamaları Türkçedir.

## GitHub'a yükleme

1. ZIP dosyasını çıkart.
2. [ybeststudio/ybeststudio](https://github.com/ybeststudio/ybeststudio) deposunu aç.
3. **Add file → Upload files** seçeneğini kullan.
4. Paketin içindeki **README.md dosyasını ve assets klasörünü birlikte** yükle. Bunları deponun ana dizinine yerleştir; üstteki `beststudio-profile` klasörünü yükleme.
5. **Commit changes** ile kaydet ve profilini aç.

README'nin yolu `README.md`, animasyonun yolu `assets/hero.svg` olmalıdır. Yalnızca README metnini kopyalarsan üst görsel, assets klasörünü yükleyene kadar görünmez.

Profil README'sinin görünmesi için depo adı kullanıcı adıyla aynı olmalı, depo public olmalı ve ana dizindeki README.md boş olmamalıdır. [GitHub'ın açıklaması](https://docs.github.com/en/account-and-profile/how-tos/profile-customization/managing-your-profile-readme).

## Paket içeriği

| Dosya | İşlev |
| :--- | :--- |
| `README.md` | Kullanıma hazır profil metni ve bağlantılar. |
| `assets/hero.svg` | Kendine ait animasyonu olan Best Studio başlığı. |
| `assets/hero-static.svg` | Aynı tasarımın hareketsiz sürümü. |
| `assets/hero-preview.png` | Başlık tasarımının PNG önizlemesi. |
| `KURULUM.md` | Bu açıklamalar; profilin görünmesi için yüklemen gerekmez. |

## Görünüm seçenekleri

**Hareketsiz başlık:** README'nin ilk görselinde `assets/hero.svg` yolunu `assets/hero-static.svg` olarak değiştir.

**İstatistikleri başlangıçta kapalı gösterme:** `<details open>` satırını `<details>` yap. Ziyaretçi başlığa tıklayarak kartları açabilir.

**İstatistikleri kaldırma:** `## GitHub Activity` başlığı altındaki `<details open>` ile `</details>` arasını sil. Doğrudan GitHub bağlantıları yerinde kalır.

**Renkler:** Başlıktaki ve rozet URL'lerindeki ana renkler `#0B101A` (zemin), `#65D9F5` (vurgu), `#AFBACB` (ikincil metin) ve `#243549` (çizgi) olarak seçildi.

## Görsel davranış ve servisler

- Başlığın animasyonu SVG dosyasının içindedir. Harici sunucuya, JavaScript'e, API anahtarına veya GitHub Actions kurulumuna ihtiyaç duymaz. Hareketi azaltma tercihi için SVG içinde bir stil kuralı ve ayrıca statik dosya bulunur.
- GitHub, README HTML'sindeki JavaScript'i ve serbest stilleri temizler. Bu nedenle efekt ayrı bir SVG görseli olarak uygulanır. [GitHub Markup](https://github.com/github/markup).
- Teknoloji ve iletişim rozetleri [Shields.io](https://shields.io/) tarafından sağlanır.
- Genel istatistikler ve dil kartı için [GitHub Stats Extended](https://github.com/stats-organization/github-stats-extended), katkı serisi için [GitHub Readme Streak Stats](https://github.com/DenverCoder1/github-readme-streak-stats) kullanılır. Harici servisler zaman zaman gecikebilir veya kota sınırına takılabilir.
- Eski [GitHub Readme Stats](https://github.com/anuraghazra/github-readme-stats) projesinin güncel README'si bakımının durduğunu belirtiyor ve GitHub Stats Extended'a yönlendiriyor. Bu pakette yeni servis kullanılır.
- `count_private=true` eklemek özel depolara erişim sağlamaz. Bu pakette özel depo erişimi ve kişisel erişim anahtarı kullanılmaz.
- Dil kartındaki oranlar depolardaki kod dağılımını gösterir; kişisel uzmanlık puanı değildir.

## Proje açıklamaları

Seçilen proje açıklamaları hesabındaki herkese açık depo tanıtımlarından özetlendi:

- [Anka2Project](https://github.com/ybeststudio/Anka2Project)
- [M2-Sentinel-Core](https://github.com/ybeststudio/M2-Sentinel-Core)
- [Metin2-Web-Client](https://github.com/ybeststudio/Metin2-Web-Client)

İletişim adresleri verdiğin README'den korundu. Profilde yeni bir unvan, deneyim yılı veya ölçülmemiş performans sonucu eklenmedi.
